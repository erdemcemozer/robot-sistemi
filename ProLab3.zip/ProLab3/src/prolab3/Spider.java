/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prolab3;
/**
 *
 * @author Erdem Özer
 */
public  class Spider extends Gezgin_Robotlar{
  Spider(int motorSayisi,int yuk,int uzuv_sayisi){
        super(motorSayisi,yuk);
        this.motorSayisi=motorSayisi;
        this.yuk=yuk;
        this.uzuv_sayisi=uzuv_sayisi;
    }
}