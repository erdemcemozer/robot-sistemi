/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prolab3;

/**
 *
 * @author Erdem Özer
 */
public interface Robotlar {
 public void ileri(int y);
    public void geri(int y);
    public void saga(int x);
    public void sola(int x);
    public void sonKonum();
    public void sureyiGoster(int mesafe,String robot,int engel_sayisi);
}